import java.io.*;
import java.net.*;
import java.util.*;

public class SocketClientBolsa {
    public static void main(String[] args) throws Exception  {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Cual es el código");
        String cod = teclado.next();
        System.out.println("Código acción bursatil: "+cod);
        boolean salir = false;
        String servidor = "localhost";
        int puerto = 6666;
        Socket socket = new Socket(servidor, puerto);
        DataOutputStream flujoSalida = new DataOutputStream(socket.getOutputStream());
        flujoSalida.writeUTF(cod.toUpperCase());
        ObjectInputStream stream = new ObjectInputStream(socket.getInputStream());
        accionbolsa accionbolsa = (accionbolsa) stream.readObject();
        if (accionbolsa.getnombre().equals("")){
            salir = true;
            System.out.println("Accion "+cod+" no encontrado");
        }
        while (salir == false) {
            
            System.out.println("¿Que información desea conocer (1=Valor Actual/2=Valor Mínimo/3=Valor Máximo/4=Salir)?");
            int info = teclado.nextInt();
            if (info==1) {
                System.out.println("el valor actual "+accionbolsa.getnombre() +" es "+accionbolsa.getactu());
            }else if (info==2) {
                    System.out.println("el valor minimo "+accionbolsa.getnombre() +"es "+accionbolsa.getmin());
            }else if(info == 3){
                
                    System.out.println("el valor maximo "+accionbolsa.getnombre() +"es "+accionbolsa.getmax());
            }else if(info==4){
                System.out.println("Saliendo");
                salir=true;
            }else{
                System.out.println("Numero no valido");
            }
            socket.close();
        }
        teclado.close();
    } //main
} //class
