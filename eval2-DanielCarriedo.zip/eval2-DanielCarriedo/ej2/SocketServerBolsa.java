import java.io.*;
import java.net.*;
import java.util.*;

//Clase para implementar la acción o el valor bursátil
class accionbolsa implements Serializable {
    
        private String nombre_accion;
        private String codigo_accion;
        private double valor_actual,valor_minimo, valor_maximo;
       
        public accionbolsa(String nombre, String codigo, double actual, double min, double max) {
            this.nombre_accion = nombre;
            this.codigo_accion = codigo;
            this.valor_actual = actual;
            this.valor_minimo = min;
            this.valor_maximo = max;
            
        }
        public String getnombre(){
            return this.nombre_accion;
        }
        public String getcod(){
            return this.codigo_accion;
        }
        public double getactu(){
            return this.valor_actual;
        }
        public double getmin(){
            return this.valor_minimo;
        }
        public double getmax(){
            return this.valor_maximo;
        }
      
    }
    
    public class SocketServerBolsa {
        public static void main(String[] args) throws Exception {
            int numeroPuerto = 6666;// Puerto
            ServerSocket servidor = new ServerSocket(numeroPuerto);  
        Socket clienteConectado = null;
            ArrayList <accionbolsa>  lista_acciones = new ArrayList<>();
            lista_acciones.add(new accionbolsa("Banco Bilbao Vizcaya","BBVA",9.286,9.110,9.296));
        lista_acciones.add(new accionbolsa("Banco Santander","SANT",3.824,3.782,3.849));
        lista_acciones.add(new accionbolsa("Iberdrola","IBER",10.965,10.855,10.980));
        lista_acciones.add(new accionbolsa("Repsol","REPS",13.620,13.480,13.670));       
              
        System.out.println("Servidor bolsa preparado");
        while(true) {
        clienteConectado=servidor.accept();
        InputStream inputStream = clienteConectado.getInputStream();
        DataInputStream entrada = new DataInputStream(inputStream);
        //OutputStream outputStream ;
               ObjectOutputStream salida = new ObjectOutputStream(clienteConectado.getOutputStream());
        String cod = entrada.readUTF();
        
        for(int i = 0;i<lista_acciones.size();i++){
            if(cod.equals(lista_acciones.get(i).getcod())){
               salida.writeObject(lista_acciones.get(i));
            }
           }
           salida.writeObject(new accionbolsa("","",0,0,0));
          
        } // while
        //servidor.close();
    } // main()
    
} // class
