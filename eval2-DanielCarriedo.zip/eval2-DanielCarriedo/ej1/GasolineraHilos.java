//Clase que implementa la Gasolinera

import java.util.LinkedList;

class Gasolinera {
    private LinkedList<String> cola = new LinkedList<String>();
    private int surtidoresdisponibles = 3;
    //método que simula la entrada en el surtidor y el repostaje de gasolina
    synchronized void entrarSurtidor(String c) {
        cola.add(c);
		while (surtidoresdisponibles==0) {
            try {
                wait();
            } catch (Exception e) {
                // TODO: handle exception
            }
        }
        surtidoresdisponibles--;
        System.out.println("cliente "+c+" entrando al surtidor");
        System.out.println("Surtidores disponibles "+surtidoresdisponibles);
    }

    //método que simula la salida del surtidor
	synchronized void salirSurtidor(String c) {
        cola.removeFirst();
        surtidoresdisponibles++;
        System.out.println("cliente "+c+" terminó de repostar y se va del surtidor");
        System.out.println("Surtidores disponibles "+surtidoresdisponibles);
        notifyAll();
    }
}

//Clase que implementa el vehículo/cliente
class Cliente extends Thread {
    private Gasolinera gasolinera;
    private String c;
     Cliente(Gasolinera gasolinera,String c){
        this.gasolinera = gasolinera;
        this.c = c;
    }
	public void run(){
        gasolinera.entrarSurtidor(c);
        try {
            Thread.sleep(10000);
        } catch (Exception e) {
            // TODO: handle exception
        }
        gasolinera.salirSurtidor(c);
    }
}

public class GasolineraHilos {
    public static void main(String[] args) {
      Gasolinera gasolinera = new Gasolinera();

      Cliente c1 = new Cliente(gasolinera,"1");
	  Cliente c2 = new Cliente(gasolinera, "2");
      Cliente c3 = new Cliente(gasolinera, "3");
	  Cliente c4 = new Cliente(gasolinera,"4");
	  Cliente c5 = new Cliente(gasolinera, "5");
      Cliente c6 = new Cliente(gasolinera, "6");
      Cliente c7 = new Cliente(gasolinera,"7");
	  Cliente c8 = new Cliente(gasolinera, "8");
      Cliente c9 = new Cliente(gasolinera, "9");
      Cliente c10 = new Cliente(gasolinera,"10");

      c1.start();
      c2.start();
      c3.start();
      c4.start();
      c5.start();
      c6.start();
      c7.start();
      c8.start();
      c9.start();
      c10.start();
    }
}

